

#====================================================

rm(list=ls())
graphics.off()




mirror = 'https://cloud.r-project.org/'

if (!is.element("shiny", installed.packages()[,1])) {install.packages("shiny", dependencies = TRUE, repos = mirror)}
if (!is.element("DT", installed.packages()[,1])) {install.packages("DT", dependencies = TRUE, repos = mirror)}
if (!is.element("RODBC", installed.packages()[,1])) {install.packages("RODBC", dependencies = TRUE, repos = mirror)}
if (!is.element("readxl", installed.packages()[,1])) {install.packages("readxl", dependencies = TRUE, repos = mirror)}
if (!is.element("writexl", installed.packages()[,1])) {install.packages("writexl", dependencies = TRUE, repos = mirror)}
if (!is.element("tidyverse", installed.packages()[,1])) {install.packages("tidyverse", dependencies = TRUE, repos= mirror)}
if (!is.element("forecast", installed.packages()[,1])) {install.packages("forecast", dependencies = TRUE, repos = mirror)}
if (!is.element("tseries", installed.packages()[,1])) {install.packages("tseries", dependencies = TRUE, repos = mirror)}
if (!is.element("plotly", installed.packages()[,1])) {install.packages("plotly", dependencies = TRUE, repos = mirror)}


library(shiny)
library( shinyWidgets)
library(shinyjs)
#library(shinydashboard)
#library(shinyBS)

library(DT)
library(RODBC)
library(readxl)
library(writexl)
library(tidyverse)
library(forecast)
library(tseries)
library(plotly)

library(lubridate)


# move defects detection to backend server !!!


#w_folder= getwd()
#w_folder= "H:\\rshiny\\BAN_Analytics\\"

w_folder= "H:\\rshiny\\BAN_source\\"
sett_file = "BAN_settings.xlsx"
lib_file = "BAN_library.R"


servername = 'TMI155LWINX\\SQLEXPRESS'
basename = 'BAN_Analytics'

# connection
conn <- odbcDriverConnect(paste0("driver=SQL Server;server=", servername, ';database=', basename))



source(paste0(w_folder, lib_file)) 


specs  <- read_excel(paste0(w_folder, sett_file ), sheet = "Specs")
progs  <- read_excel(paste0(w_folder, sett_file ), sheet = "Programs")
progs <-  progs[which(progs['Active (Y/N)'] == 'Y'), ] %>%  select('Program Index Number', 'Part Number')
colnames(progs) = c('PartType', 'PartNumber')


infomessage = function(title, txt)
{
  showModal(
    modalDialog( title = title,   txt,   easyClose = TRUE,   footer = NULL))        
}



get_sql = function(sql, conn) {
  
  res = sqlQuery(conn, sql, errors = TRUE)
  return(res)
  
}


ui <- fluidPage(

  useShinyjs(),
  titlePanel(h3("Parameters"), windowTitle = 'BAN monitoring'),


  
  sidebarLayout(

    sidebarPanel(

      dateRangeInput("dates", label = h4("Time range")),

      # Button
      actionButton("load_range", "Load as Range"),
      

      fluidRow(width=12,
               column(width=6,
                      selectInput("last_sel_input", "",  choices = c('days','weeks','months')) ),
               column(width=6,
                      numericInput("per_input", "", 1,  min = 1, max = 100, step = 1) ) ),           

      actionButton("load_last", "Load as Periods"),

      br(), br(),
      radioButtons("radio_mode", label = h4("Mode:"),
                   choices = list("batch" = 1, "continious" = 2), 
                   selected = 1),
      disabled(actionButton("run_cont", "Start monitoring", width = '100%')),        
      

      width = 2
    ),
    
    
    
    
    mainPanel(


      tabsetPanel(
        id = 'tabs',

        
        
        #----------------------------- Continious tab -----------------------
        
        tabPanel("Monitoring",
                 
                 
                 br(),
                 fluidRow(width=12,
                          br(),
                          column(width=12,   plotlyOutput("plot_qua_cont", height = 300))
                 ),
                 
                 fluidRow(width=12,
                          column(width=11,   plotlyOutput("plot_defect_cont", height = 500))
                 )
                 
                 
        ),             
        
        
        
        #----------------------------- Summary tab -----------------------
        

        tabPanel("Summary",
                 
                 br(),
                 fluidRow(width=12,
                          br(),
                          column(width=6,   plotlyOutput("plot_qua_sum", height = 300)),
                          column(width=6,   plotlyOutput("plot_ateq_sum", height = 300))
                          ),
                 
                 fluidRow(width=12,
                          column(width=6,   plotlyOutput("plot_defect_sum", height = 300)),
                          column(width=6,   plotlyOutput("plot_fta_sum", height = 300))                          
                 ),
                 
                 
                 fluidRow(width=12,
                          column(width=6,   plotlyOutput("plot_fault_sum", height = 300)),
                          
                          column(width=5,  textOutput('out_act_text')),  #verbatimTextOutput('out_act_text') )
                          column(width=5,  DT::dataTableOutput("sum_act_table")) 
                 ),

                 tags$head(tags$style("#out_act_text{color: black; font-size: 16px; font-style: bold; }"  ) )
                          
                          
        ),
        
   

        tabPanel("Quality",

                 fluidRow(width=6,
                   column(width=3,
                          pickerInput("BatchNo_def_input", "BatchMoNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),

                   column(width=3,
                          pickerInput("BatchLot_def_input", "BatchLotNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
                   column(width=3,
                          pickerInput("PartNumber_def_input", "PartNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),

                 br(), column(width=3,   disabled(actionButton("calc_def", "Apply")) )
                 ),
                 
                 br(),
                 fluidRow(width=12,
                          br(),
                          column(width=12,   plotlyOutput("plot_qua_def", height = 300))
                 ),
                 
                 fluidRow(width=12,
                          br(),
                          column(width=12,   plotlyOutput("plot_defect_def", height = 500))
                          ),

                 br(),
                 DT::dataTableOutput("table_def", width=1500),
                 
                 br(), 
                 fluidRow(width=12,
                          column(width=2,  downloadButton("exp_def", "Export Data"))      
                 )
                 
        ),
        
        
        
        
        #----------------------------- Faults tab -----------------------
        
        
        
        tabPanel("Faults",
                 
                 
                 fluidRow(width=6,
                          column(width=3,
                                 pickerInput("Station_flt_input", "Station:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
                          
                          column(width=3,
                                 pickerInput("Descr_flt_input", "Description:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
                          
                          br(), column(width=3,   disabled(actionButton("calc_flt", "Apply")) )
                 ),
                 
                 br(),
                 fluidRow(width=12,
                          br(),
                          column(width=12,   plotlyOutput("plot_day_flt", height = 300))
                 ),
                 
                 fluidRow(width=12,
                          br(),
                          column(width=12,   plotlyOutput("plot_hour_flt", height = 500))
                 ),
                 
                 br(),
                 DT::dataTableOutput("table_flt", width=1500),
                 
                 br(), 
                 fluidRow(width=12,
                          column(width=2,  downloadButton("exp_flt", "Export Data"))      
                 )                 
                 
                 
        ),        
        
        
        #----------------------------- ATEQ tab -----------------------
        
        tabPanel("ATEQ",

                 fluidRow(width=12,

                  column(width=2,
                         pickerInput("BatchNo_ateq_input", "BatchMoNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ) ,
                  
                  column(width=3,
                         pickerInput("BatchLot_ateq_input", "BatchLotNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
                  column(width=3,
                         pickerInput("Station_ateq_input", "Station:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
                  
                  br(),
                  column(width=2,   disabled(actionButton("calc_ateq", "Apply") ) )
                  ) ,


                  fluidRow(width=12,
                           
                      column(width=12,   plotlyOutput("plot_ateq_day", height = 300   ) ),
                      column(width=12,   plotlyOutput("plot_ateq_scatt", height = 700   ) )  ,

                  DT::dataTableOutput("table_ateq_raw")
                  ),
                 
                 br(),
                 fluidRow(width=12,
                          column(width=2,  downloadButton("exp_ateq", "Export Data"))
                 )
                 


        ),

        
        
        
        #----------------------------- FTA tab -----------------------



        tabPanel("FTA",

               fluidRow(width=12,
                        
                        column(width=2,
                               pickerInput("BatchNo_fta_input", "BatchMoNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ) ,
                        
                        column(width=3,
                               pickerInput("BatchLot_fta_input", "BatchLotNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
                        column(width=3,
                               pickerInput("Station_fta_input", "Station:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
                        
                        br(),
                        column(width=2,   disabled(actionButton("calc_fta", "Apply") ) )
               ) ,
               
               
               fluidRow(width=12,
                        
                        column(width=12,   plotlyOutput("plot_fta_day", height = 300   ) ),
                        column(width=12,   plotlyOutput("plot_fta_scatt", height = 700   ) )  ,
                        
                        DT::dataTableOutput("table_fta_raw")
               ),
               
               br(),
               fluidRow(width=12,
                        column(width=2,  downloadButton("exp_fta", "Export Data"))
               )                 
                 
        ),

        
        #----------------------------- Custom tab -----------------------
        
        
        
        tabPanel("Custom",
                 
                 fluidRow(width=12,
                          
                          # column(width=2,
                          #     dateRangeInput("Time_cust_input", label = "Time range") ),
                          
                          column(width=2,
                                 pickerInput("BatchNo_cust_input", "BatchMoNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ) ,
                          
                           column(width=3,
                                  selectInput("Var1_cust_input", "Parameter 1:",  choices = c(''),  selected = 1,  width = "600px") ) ,

                           column(width=3,
                                  selectInput("Var2_cust_input", "Parameter 2:",  choices = c(''),  selected = 1,  width = "600px") ),
                          
                          br(), column(width=2,   disabled( actionButton("calc_cust", "Apply") ) )
                 ) ,
                 
                 
                 

                 fluidRow(width=12,
                          
                          column(width=12,   plotlyOutput("plot_cust_day", height = 300
                          ) ),
                          
                          column(width=12,   plotlyOutput("plot_cust_scatt", height = 700
                          ) )  ,
                          
                          DT::dataTableOutput("table_cust_raw")
                 ),
                 
                 br(),
                 fluidRow(width=12,
                          column(width=2,  downloadButton("exp_cust", "Export Data"))
                 )
                 
        ),            
        
        
        
        #----------------------------- Actuation tab -----------------------

        tabPanel("Actuation",


           fluidRow(width=12,
                    column(width=2,  pickerInput("Station_act_input", "Station:",  choices = c(''),  multiple = FALSE) ) ,
                    column(width=2,  pickerInput("Actuation_act_input", "Actuation:",  choices = c(''),  multiple = FALSE) ) ,
                    column(width=2,  pickerInput("Stroke_act_input", "Stroke:",  choices = c(''),  multiple = FALSE) ) ,
                    br(),
                    column(width=2,   disabled( actionButton("calc_act", "Apply")) ) ),
          fluidRow(width=12,         
                    column(width=2,   sliderInput("sliderLoess", label = "Approximation span", min = 0.05, max = 1, value = 0.25 )) ,                  
                    column(width=12,  plotlyOutput("plot_act", height = 700  )
                    ),
                    
                    DT::dataTableOutput("act_table")

           )

        )

      )
      
    )
  )
)






server <- function(input, output, session) {


  rea_cont <- reactiveValues(qua = NULL, decode = NULL)
  rea_sum <- reactiveValues(qua = NULL, day_decode = NULL)
  rea_times <- reactiveValues(starttime = NULL, endtime = NULL)
  rea_def <- reactiveValues(qua = NULL, date_sel = NULL, def_hr = NULL, hr_sel = NULL, def = NULL)
  rea_flt <- reactiveValues(date_agg = NULL, date_sel = NULL, flt_hr = NULL, hr_sel = NULL, flt = NULL)
  rea_ateq <- reactiveValues(raw = NULL, date_agg = NULL, date_raw = NULL, date_sel = NULL, brush = NULL)
  rea_fta <- reactiveValues(raw = NULL, date_agg = NULL, date_raw = NULL, date_sel = NULL, brush = NULL)  
  rea_cust <- reactiveValues(vname1 = NULL, vname2 = NULL, raw = NULL, date_raw = NULL, date_sel = NULL, date_agg = NULL )
  rea_act <- reactiveValues(out_act = NULL, ds = NULL, ds1 = NULL)

  hideTab(inputId = "tabs", target = c('Monitoring'))


  observeEvent(input$radio_mode, {
    
    if (input$radio_mode == 1) { # batch mode
      
      enable('load_last')
      enable('load_range')
      disable('run_cont')
      
      hideTab(inputId = "tabs", target = c('Monitoring'))
      #hideTab(inputId = "tabs", target = c('Quality0'))
      
      
      showTab(inputId = "tabs", target = c('Summary'))
      #showTab(inputId = "tabs", target = c('Quality0'))
      showTab(inputId = "tabs", target = c('Quality'))
      showTab(inputId = "tabs", target = c('Faults'))
      showTab(inputId = "tabs", target = c('ATEQ'))
      showTab(inputId = "tabs", target = c('FTA'))
      showTab(inputId = "tabs", target = c('Custom'))
      showTab(inputId = "tabs", target = c('Actuation'))
      
      
    } else if (input$radio_mode == 2) {  # continious mode
      
      disable('load_last')
      disable('load_range')
      enable('run_cont')

      showTab(inputId = "tabs", target = c('Monitoring'))
      
      hideTab(inputId = "tabs", target = c('Summary'))
      #hideTab(inputId = "tabs", target = c('Quality0'))
      hideTab(inputId = "tabs", target = c('Quality'))
      hideTab(inputId = "tabs", target = c('Faults'))
      hideTab(inputId = "tabs", target = c('ATEQ'))
      hideTab(inputId = "tabs", target = c('FTA'))
      hideTab(inputId = "tabs", target = c('Custom')) 
      hideTab(inputId = "tabs", target = c('Actuation'))
      
    }
    
    
  })
  
  
  
   

  load_data = function (starttime, endtime) {

    withProgress({
      
      #........... Parts data ...................

      setProgress(message = "Parts data loading...")
      incProgress(0.3, detail = paste("step ", 1))

      st_sql = get_query('parts', starttime, endtime )
      df_parts <<- get_sql(st_sql, conn)


      
      if (check_df('df_parts', mes=1) < 0) { return() }
        

      ix = colnames(df_parts) == 'BatchSerialNumber'
      colnames(df_parts)[ix] = 'SerialNumber'
      

      
      df_parts <- left_join(df_parts, progs, by = c("PartType"))
      
      df_parts$date = as.Date(df_parts$StartTime)
      #tmp$date = format(as.POSIXct(tmp$StartTime),  " %H:%M") # "%d/%m/%Y %H:%M")
      df_parts$hours = as.numeric(strftime(df_parts$StartTime, format="%H")) #format="%H:%M:%S"))

      df_parts <<- df_parts
      
      unique(df_parts['PartType'])

      
      #........... Quality data ...................

      batch_list <- sort(as.vector(unique(df_parts$BatchMoNumber)))
      batchLot_list <- sort(as.vector(unique(df_parts$BatchLotNumber)))
      PartNumber_list <- sort(as.vector(unique(df_parts[['PartNumber']])))
      
      updatePickerInput(session, "BatchNo_qua_input",
                        choices = batch_list, selected = batch_list  )


      updatePickerInput(session, "BatchNo_def_input",
                        choices = batch_list, selected = batch_list  )      

      updatePickerInput(session, "BatchLot_def_input",
                        choices = batchLot_list, selected = batchLot_list  )      
      
      updatePickerInput(session, "PartNumber_def_input",
                        choices = PartNumber_list, selected = PartNumber_list  )      
      
      df_parts_ag = aggregate(x = df_parts[, c('good_parts', 'bad_parts')],
                        by = list(df_parts$date, df_parts$hours, 
                                  df_parts$BatchMoNumber, df_parts$BatchLotNumber, df_parts$PartNumber), 
                                  FUN = "sum",  na.rm = TRUE)
      colnames(df_parts_ag)[1:5] = c('date', 'hours', 'BatchMoNumber', 'BatchLotNumber', 'PartNumber')
      df_parts_ag <<- df_parts_ag
      
      
      #........... Faults data ...................
      
      
      st_sql = get_query('faults', starttime, endtime )
      df_faults <<- get_sql(st_sql, conn)      
      
      
      x <- sort(as.vector(unique(df_faults$Station)))
      
      updatePickerInput(session, "Station_flt_input",
                        choices = x, selected = x  )      
      
      x <- sort(as.vector(unique(df_faults$Description)))
      
      updatePickerInput(session, "Descr_flt_input",
                        choices = x, selected = x  )      
      


      #........... ATEQ data ...................

      df_ateq = data.frame()

      ix = which( (df_parts$S111AteqPressure > 0) | (df_parts$S111AteqLeak > 0) | (df_parts$S101VacuumSideFlowResults > 0) )
      tmp = df_parts[ix, ]
      tmp$Station = '111'
      tmp$Pressure = tmp$S111AteqPressure
      tmp$Leak = tmp$S111AteqLeak
      tmp$Flow = tmp$S101VacuumSideFlowResults
      df_ateq = rbind(df_ateq, tmp)


      ix = which( (df_parts$S112AteqPressure > 0) | (df_parts$S112AteqLeak > 0) | (df_parts$S102VacuumSideFlowResults > 0) )
      tmp = df_parts[ix, ]
      tmp$Station = '112'
      tmp$Pressure = tmp$S112AteqPressure
      tmp$Leak = tmp$S112AteqLeak
      tmp$Flow = tmp$S102VacuumSideFlowResults
      df_ateq = rbind(df_ateq, tmp)


      ix = which( (df_parts$S113AteqPressure > 0) | (df_parts$S113AteqLeak > 0) | (df_parts$S103VacuumSideFlowResults > 0) )
      tmp = df_parts[ix, ]
      tmp$Station = '113'
      tmp$Pressure = tmp$S113AteqPressure
      tmp$Leak = tmp$S113AteqLeak
      tmp$Flow = tmp$S103VacuumSideFlowResults
      df_ateq = rbind(df_ateq, tmp)


      cols = c('StartTime', 'EndTime', 'date', 'SerialNumber', 'BatchMoNumber', 'BatchLotNumber',
              'Station', 'Pressure',  'Leak', 'Flow')


      df_ateq <<- df_ateq[cols]

      df_ateq$Station <<- as.character(df_ateq$Station)


      updatePickerInput(session, "BatchNo_ateq_input",
                        choices = batch_list, selected = batch_list )

      updatePickerInput(session, "BatchLot_ateq_input",
                        choices = batchLot_list, selected = batchLot_list  )      
      
      x <- sort(as.vector(unique(df_ateq$Station)))
      updatePickerInput(session, "Station_ateq_input",
                        choices = x, selected = x  )      
      
      
      #........... FTA data ...................

      updatePickerInput(session, "BatchNo_fta_input",
                        choices = batch_list, selected = batch_list )

      updatePickerInput(session, "BatchLot_fta_input",
                        choices = batchLot_list, selected = batchLot_list  )

      updatePickerInput(session, "Station_fta_input",
                        choices = x, selected = x  )
      


      # .......... Custom list data .........
      
      st_sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS  WHERE TABLE_NAME = N'DataPart'"
      cust_list <- (get_sql(st_sql, conn))

      updatePickerInput(session, "BatchNo_cust_input",
                        choices = batch_list, selected = batch_list )
      
      cols = c("Id", "StartTime", "EndTime", "S10LotTime" , "S20LotTime", "S30LotTime", "S50LotTime", "S90LotTime", "BatchMoNumber", "BatchLotNumber")
      tmp = setdiff(unlist(cust_list), cols)
      updatePickerInput(session, "Var1_cust_input",
                        choices = tmp, selected = "S101PressureSideFlowResults" )      
      
      updatePickerInput(session, "Var2_cust_input",
                        choices = tmp, selected = "S111AteqLeak" )
      

      
      # .......... Actuation data .........

      setProgress(message = "Actuation data loading...")
      incProgress(0.5, detail = paste("step ", 2))

      st_sql = get_query('actuation', starttime, endtime )
      df_act <<- get_sql(st_sql, conn)

      x <- sort(as.vector(unique(df_act$Station)))
      updatePickerInput(session, "Station_act_input", choices = c(), selected = 0 )
      updatePickerInput(session, "Station_act_input",
                        choices = x
                        , selected = head(x, 1)
      )

      x <- sort(as.vector(unique(df_act$Act_Name)))
      updatePickerInput(session, "Actuation_act_input",
                        choices = x
                        , selected = x
      )

      x <- sort(as.vector(unique(df_act$Stroke)))
      updatePickerInput(session, "Stroke_act_input",
                        choices = x
                        , selected = x
      )

      df_act$DateCreated <<- as.POSIXct(df_act$DateCreated)

      incProgress(1.0, detail = paste("step", 3))
      setProgress(message = "Done")
      #Sys.sleep(1)
     })

  }
  
  # function checks if the dataframe exists and not empty
  check_df = function (dfname, mes=0) {
    
    flag = FALSE
    flag = !exists(dfname)
    if (!flag) { 
      s = paste0('nrow(', dfname,')==0')
      flag = eval(parse(text = s)) 
      }
    r = 1    
    if (flag)  {
      if (mes == 1) { infomessage('Warning', paste0('No data was loaded: ', dfname)) }
      r = -1
    } 
    return(r)    
  }

  
  
    
  start_analysis = function () {
    
    withProgress({

        #=================== ACTUATION OUTLIERS ==============
      
        setProgress(message = "Actuation data analysis...")
        incProgress(0.5, detail = paste("step ", 2))
      
        
        act_history = 30
        last_hours = 4
        show_plots = FALSE
        
        cols =  c("Stroke", "Station", "Act_Name")
        tmp0 = df_act[!is.na(df_act$Parameter_value), ]
        tmp0$DateCreated =  as.POSIXct(tmp0$DateCreated)
        
        
       # ix = which((as.Date(tmp0$DateCreated) <= as.Date('2020-01-08')) & (as.Date(tmp0$DateCreated) > as.Date('2019-12-01')) )
        ix = which(as.Date(tmp0$DateCreated) >= max(as.Date(tmp0$DateCreated)) - as.difftime(act_history, unit='days') )
        tmp0 = tmp0[ix, ]
        
        
        tmp0$cnt = 1  
        tmp = aggregate(x =tmp0[, c("cnt")], by = list(tmp0$Stroke, tmp0$Station, tmp0$Act_Name), FUN = "sum",  na.rm = TRUE)
        colnames(tmp)[1:4] = c(cols, 'cnt')
        
        ix = which(tmp$cnt > 10 )
        tmp = tmp[ix, ]

        out_act = data.frame()
        
        if (nrow(tmp) > 0) {
          
          i = 5
          n = 0
          
          for (i in rownames(tmp)) {  
            tmp1 = merge(tmp[i, ], tmp0, by = cols, all.x = TRUE, sort = FALSE)
            tmp1 = tmp1[order(tmp1$DateCreated), ]
            
            q = quantile(tmp1$Parameter_value, c(0.25, 0.75))
            ymin = as.numeric(q[1] - 1.5*(q[2]-q[1]))
            ymax = as.numeric(q[2] + 1.5*(q[2]-q[1]))
            
            if ((ymin + ymax) > 0) {
              
              #dd = max(tmp1$DateCreated) - as.difftime(1, unit='days')
              dd = max(tmp1$DateCreated) - as.difftime(last_hours, unit='hours')
              tmp2 = tmp1[tmp1$DateCreated <= dd, ]
              tmp3 = tmp1[tmp1$DateCreated > dd, ]
            
              ylmean = mean(tmp3$Parameter_value)
              ylmin = ylmean 
              ylmax = ylmean 
              
              ymean = mean(tmp2$Parameter_value)
              sko = sd(tmp2$Parameter_value)
              
              if ( ((ylmin < ymin) & (ylmin < ymean - sko) ) | 
                   ((ylmax > ymax) & (ylmax > ymean + sko) ) 
                   )  {
                  if (show_plots) {
                      plot(tmp1$DateCreated, tmp1$Parameter_value)
                      lines(tmp1$DateCreated, tmp1$Parameter_value)
                      abline(h = ymin, col=c("red"))
                      abline(h = ymax, col=c("red"))
                      abline(h = ymean, col=c("blue"))
                      abline(h = ylmean, col=c("magenta"))
                      abline(h = ymean - sko, col=c("green"))
                      abline(h = ymean + sko, col=c("green"))
                      title(paste(i, ' : [', round(ymin, 1), ', ', round(ymax, 1), ']' ))
                  }
                  tmp3$hmean = ymean
                  tmp3$qmin = ymin
                  tmp3$qmax = ymax
                  tmp3$sdmin = ymean - sko
                  tmp3$sdmax = ymean + sko
                  tmp3$var = round(((ylmean - ymean) / sko - 1)*100, 1)
                  out_act = rbind(out_act, tmp3)
                  
                  n = n + 1
                }
            }  
          }
          if (length(out_act) > 0) {
            
            
            out_act$DateCreated  = as.POSIXct(out_act$DateCreated)          
            out_act = out_act[, c("Stroke", "Station", "Act_Name", "DateCreated", "Parameter_value", "var", "hmean", "qmin",  "qmax",  "sdmin", "sdmax" )]
            
            
            cols = c( "Station", "Act_Name", "Stroke")
            tmp <- out_act %>% select(cols) %>% unique() 
            tmp$inx = seq(1, nrow(tmp)) 
            

            dfi_act = df_act %>% merge(tmp, all.x = TRUE, by = cols)
            out_act = out_act %>% merge(tmp, all.x = TRUE, by = cols)   
            #out_act = merge(out_act, tmp, all.x = TRUE, by = cols)   
            
            out_act <<- out_act
            df_act <<- dfi_act

          }
        }

    })
    return ()
    
  } 
  
  
defects_decode = function (rc_list, df_prt) {
  

  get_defects = function(word, code) {
    
    x <- intToBits(code)
    ix = which(x=='01') - 1
    
    r = rc_list[rc_list$Word == word, ]
    r = r[r$Bit %in% ix, ]
    
    return(r)
  }
  
  rcodes <- df_prt %>% select('MoverRejectCode0', 'MoverRejectCode1') %>%
            filter( MoverRejectCode0 + MoverRejectCode1 > 0) %>%  unique()
  
  

  defects = data.frame()
  
  for (i in (rownames(rcodes))) {
    
    tmp =  data.frame()
    tmp1 =  data.frame()
    
    c0 = rcodes[i, ]$MoverRejectCode0
    if (c0 > 0) {
      tmp = get_defects (0, c0)
    }
    
    c1 = rcodes[i, ]$MoverRejectCode1
    if (c1 > 0) {
      tmp1 = get_defects (1, c1)
      tmp = rbind(tmp, tmp1)
    }
    
    if (nrow(tmp) > 0) {
      tmp$MoverRejectCode0 = c0
      tmp$MoverRejectCode1 = c1
      # tmp$RC_link = paste0(c0, '_', c1)
      defects = rbind(defects, tmp)
    }
  }
  
  # # Descriptions id labeling 
  # tmp1 <- data.frame(unique(tmp$Description)) 
  # colnames(tmp1) = c('Description')
  # tmp1$defect_id <- as.integer(rownames(tmp1))
  # tmp <- left_join(tmp, progs, by = c('PartType'))
  # 
  # def_decode <<- left_join(tmp, tmp1, by = c('Description'))  
  
  
  # Descriptions id labeling 
  tmp1 <- data.frame(unique(defects$Description)) 
  colnames(tmp1) = c('Description')
  tmp1$defect_id <- as.integer(rownames(tmp1))
  
  defects <- left_join(defects, tmp1, by = c('Description'))  
  
  
  res <-  df_prt %>% select( "StartTime", "EndTime", "BatchMoNumber", "BatchLotNumber", "PartType", "MoverRejectCode0", "MoverRejectCode1", "bad_parts", "good_parts") %>%
          filter(MoverRejectCode0 + MoverRejectCode1 >0)
  
  res <- left_join(res, progs, by = c('PartType'))

  res <- left_join(res,  defects, by = c('MoverRejectCode0', 'MoverRejectCode1'))


 return(res) 
}
  
  
  


  observeEvent(input$load_range, {
    
    rea_times$starttime = input$dates[1]
    rea_times$endtime = input$dates[2]
    
  })


  observeEvent(input$load_last, {
    
    endtime = Sys.Date()
    endtime = as.Date("2020-01-25")

    if (input$last_sel_input == 'months') {
        starttime = endtime - as.difftime(input$per_input*365.25/12, unit='days')
    } else {
        starttime = endtime - as.difftime(input$per_input, unit=input$last_sel_input)
    }

    rea_times$starttime = starttime
    rea_times$endtime = endtime    

  })

  
  
  observeEvent({rea_times$starttime
                rea_times$endtime}, {

    load_data(rea_times$starttime, rea_times$endtime)

    if (check_df('df_parts_ag') > 0) {

            rea_sum$qua <- df_parts_ag %>% group_by(date) %>%
                            summarize(good_parts = sum(good_parts),
                                      bad_parts = sum(bad_parts)) %>%
                            mutate(quality = good_parts / (good_parts + bad_parts) * 100)
    }
                  
    if (check_df('df_parts', mes=1) > 0) {                  
      
      st_sql = "
          SELECT distinct Description, Word, Bit  FROM dbo.ConfigDefect   order by word, bit
      "
      rc_list = get_sql(st_sql, conn) 
      
      # extract Stations from Description
      rc_list$Station = unlist(lapply(rc_list$Description, function(x) { unlist(strsplit(unlist(strsplit(toupper(x), " "))[1], "S"))[2] }))
      rc_list <<- rc_list
      
      
      tmp =  defects_decode(rc_list, df_parts)     
      rea_sum$day_decode <- tmp %>%  mutate(date = as.Date(StartTime)) %>% 
                    group_by(date, Description, Station) %>%
                    summarize(Defects_Number = n() )  
      def_decode <<- tmp
    }
                  
                  
     rea_sum$day_fault <- df_faults %>%  mutate(date = as.Date(Time)) %>% 
          group_by(date, Description) %>%   summarize(Faults_Number = n() )  
                  
     rea_sum$day_ateq  <- df_ateq %>%  mutate(date = as.Date(StartTime), 
                                             Leak_SD = Leak, Flow_SD = Flow) %>% 
               group_by(date) %>%   summarize(Leak = mean(Leak), Leak_SD = sd(Leak_SD),
                                              Flow = mean(Flow), Flow_SD = sd(Flow_SD))  

                  
    if (check_df('df_act', mes=1) > 0) {
      start_analysis()

      if (check_df('out_act') > 0) {
        rea_act$out_act <- out_act
      }
      showTab(inputId = "tabs", target = c('Actuation'))
    }

    if (check_df('def_decode') > 0) shinyjs::enable("calc_def") else shinyjs::disable("def_decode")
    if (check_df('df_faults') > 0) shinyjs::enable("calc_flt") else shinyjs::disable("def_flt")                   
    if (check_df('df_ateq') > 0) shinyjs::enable("calc_ateq") else shinyjs::disable("calc_ateq")                   
    if (check_df('df_ateq') > 0) shinyjs::enable("calc_fta") else shinyjs::disable("calc_fta")                   
    if (check_df('df_parts') > 0) shinyjs::enable("calc_cust") else shinyjs::disable("calc_cust")                   
    if (check_df('df_act') > 0) shinyjs::enable("calc_act") else shinyjs::disable("calc_act")                   

    rea_act$ds <- NULL
    rea_act$ds1 <- NULL
    rea_ateq$date_agg <- NULL
    rea_ateq$date_sel <- NULL
    rea_ateq$brush <- NULL
    rea_ateq$date_raw <- NULL 
    
    rea_fta$date_agg <- NULL
    rea_fta$date_sel <- NULL
    rea_fta$brush <- NULL
    rea_fta$date_raw <- NULL    

    rea_def$qua <- NULL
    rea_def$date_sel <- NULL
    rea_def$def_hr <- NULL
    rea_def$hr_sel <- NULL
    rea_def$def <- NULL

    rea_flt$date_agg <- NULL
    rea_flt$date_sel <- NULL
    rea_flt$flt_hr <- NULL
    rea_flt$hr_sel <- NULL
    rea_flt$flt <- NULL

    rea_cust$raw <- NULL
    rea_cust$date_raw <- NULL
    rea_cust$brush_raw <- NULL
    rea_cust$date_sel <- NULL
    rea_cust$date_agg <- NULL
    rea_cust$vname1 <- NULL
    rea_cust$vname2 <- NULL
      

  })
  
  
  #----------------------------- Continious mode -----------------------
  
 # ccount <<- 1
  
  
  #  function is labeling time variable tname as split by intr intervals
  split_time = function(df, tname, intr) {
    
    df$time_int = as.POSIXct(df[, tname])
    
    from = round(min(df$time_int), "hour") - hours(1)
    to = round(max(df$time_int), "hour") + hours(1)
    df$time_int <- cut( df$time_int,  breaks = seq(from, to, as.difftime(intr, units="mins") )    )    
    
    return(df)
  }
  
  
  freq_RT <<- 5  # refresh frequency (minutes)
  show_RT <<- 50  # number of records to show
  
  
  observeEvent(input$run_cont, {
    
    if (check_df('df_parts') < 0) return()
    if (check_df('def_decode') < 0) return()
    
    
    withProgress({
      
      setProgress(message = "Continious data preparing...")
      incProgress(0.5, detail = paste("step ", 1))
      
      tmp = split_time(df_parts, 'StartTime', freq_RT)
      
          
      qua0 = tmp %>% group_by(time_int) %>%
        summarize(good_parts = sum(good_parts),
                  bad_parts = sum(bad_parts)) %>%
        mutate(quality = good_parts / (good_parts + bad_parts) * 100)
  
      
      tmp = split_time(def_decode, 'StartTime', freq_RT)
      
      decode0 = tmp %>%  
               group_by(time_int, Description, defect_id, Station) %>%
               summarize(Defects_Number = n() )  
        
      
      #qua0 =  left_join(qua0, tmp, by = c('time_int') )
        
      colnames(qua0)[1] = 'date'
      qua0$date = as.POSIXct(qua0$date)
      colnames(decode0)[1] = 'date'
      decode0$date = as.POSIXct(decode0$date)    
      

      
      #  data subset to show continuously in real-time 
      #df_parts_RT <<- head(df_parts, 100)   # in test version we are take data from earliest day
      #df_parts_RT <<- tail(df_parts, 100)   # in production version we will take data from last day
      
      qua0 = head(qua0, show_RT)
      
      decode0 <<- decode0
      EndTime_plus <<- max(as.POSIXct(qua0$date))   # initialization for test version     
      rea_cont$qua <- qua0
    })

  })
  

  

  observe({
    
    
    invalidateLater(1000, session)

    if (input$radio_mode == 2) {
     
      isolate({
        # if (check_df('decode0') < 0) return()
        if (is.null(rea_cont$qua))  return()
        
        qua_RT =  rea_cont$qua 

        StartTime_plus = max(as.POSIXct(qua_RT$date))
        EndTime_plus <<- EndTime_plus + as.difftime(freq_RT, units="mins")  # test version
        #EndTime_plus = Sys.time()                          # production version
  
        print(StartTime_plus)
        print(EndTime_plus)
  
        st_sql = get_query('parts',  StartTime_plus, EndTime_plus)
        tmp =  get_sql(st_sql, conn)
  
        if (nrow(tmp) > 0) {
  
          tmp = split_time(tmp, 'StartTime', freq_RT)
  
          tmp = tmp %>% rename(date = time_int) %>%
                        group_by(date) %>%
                        summarize( good_parts = sum(good_parts),
                                   bad_parts = sum(bad_parts)) %>%
                        mutate(quality = good_parts / (good_parts + bad_parts) * 100,
                               date = as.POSIXct(date))
  
          # append newest data and remove oldest data
          qua_RT <- qua_RT %>% filter(!date %in% tmp$date)
          qua_RT <- rbind(qua_RT, tmp)
          qua_RT <- tail(qua_RT, show_RT)
          
          
          #   defects decoding
          def_RT =  rea_cont$decode
          
          tmp1 =  defects_decode(rc_list, tmp)     
          def_RT <- tmp %>%  mutate(date = as.Date(StartTime)) %>% 
            group_by(date, Description, Station) %>%
            summarize(Defects_Number = n() )  

          def_RT <- def_RT %>% filter(!date %in% tmp1$date)
          def_RT <- rbind(def_RT, tmp1)
          def_RT <- tail(def_RT, show_RT)
          
        }
        
        rea_cont$qua <- qua_RT   
        rea_cont$decode <- def_RT
      })
    
     # rea_cont$decode <- decode0 %>% filter(date %in% qua_RT$date) 

            

      # EndTime_plus = max(as.POSIXct(df_parts_RT$StartTime))   # initialization for test version
      # 
      # StartTime_plus = max(as.POSIXct(df_parts_RT$StartTime)) 
      # EndTime_plus = EndTime_plus + as.difftime(freq_RT, units="mins")  # test version
      # #EndTime_plus = Sys.time()                          # production version
      # 
      # print(StartTime_plus)
      # print(EndTime_plus)
      # 
      # st_sql = get_query('parts',  StartTime_plus, EndTime_plus)
      # tmp =  get_sql(st_sql, conn)
      # 
      # if (nrow(tmp) > 0) {
      #   
      #   ix = which(colnames(tmp) == 'BatchSerialNumber')
      #   colnames(tmp)[ix] = 'SerialNumber'
      #   df_parts_RT = df_parts_RT[ colnames(tmp) ]
      #   
      #   # append newest data and remove oldest data
      #   df_parts_RT = rbind(df_parts_RT, tmp)
      #   df_parts_RT = tail(df_parts_RT, -1 * nrow(tmp))
      # }
      # 
      # 
      #       
      # #print(ccount)
      # 
      # nn = 50  # number of records to show
      # nk = max(as.integer(rownames(qua0))) - nn
      # 
      # if (ccount + nn < nk) {
      #    
      #   tmp =  qua0[ccount:(ccount + nn), ]
      # 
      #   rea_cont$qua <- tmp
      #   rea_cont$decode <- decode0 %>% filter(date %in% tmp$date) 
      #   
      #   ccount <<- ccount + 1
      # }
       
    }
    
  })    
  
  # observe({
  #   
  #   invalidateLater(1000, session)
  #   
  #   if (input$radio_mode == 2) {
  #     
  #     if (check_df('qua0') < 0) return()
  #     if (check_df('decode0') < 0) return()
  #     
  #     
  #     #print(ccount)
  #     
  #     nn = 50
  #     nk = max(as.integer(rownames(qua0))) - nn
  #     
  #     if (ccount + nn < nk) {
  #       
  #       tmp =  qua0[ccount:(ccount + nn), ]
  #       
  #       rea_cont$qua <- tmp
  #       rea_cont$decode <- decode0 %>% filter(date %in% tmp$date) 
  #       
  #       ccount <<- ccount + 1
  #     }
  #     
  #   }
  #   
  # })     
  
  #----------------------------- Continuous tab -----------------------
  
  

  
  output$plot_qua_cont <- renderPlotly({
    
    if (length(rea_cont$qua) > 0) {
      
      tmp = rea_cont$qua
      
      p <- plot_ly(data = tmp, x = ~date)    %>%
        add_trace(y = ~(good_parts + bad_parts), 
                  line = list(color = 'rgb(120, 120, 120)', width = 1), 
                  marker = list(color = 'rgb(120, 120, 120)', size=4),
                  type = 'scatter', name = 'Total parts', yaxis = "y2", mode = 'lines+markers') %>%
        add_trace(y = ~quality, name = 'Quality, %', type = 'scatter', mode = 'lines+markers') %>%
        layout(yaxis2 = list(title = "Total parts", overlaying = "y", side = "right", automargin = T),
               yaxis = list(title = "Quality, %"),  xaxis = list(title = ""),
               title = 'Quality and Total parts over Time'
               #legend = list(orientation = "h", xanchor = "center", x = 0.5) 
               ) %>%
        
        config(displaylogo = FALSE) %>%
        config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
      p
      
    }
    
  })
  
  
  output$plot_defect_cont <- renderPlotly({

    df = rea_cont$decode
    if (length(df) > 0) {

      
      P = plot_ly(df, x=~date, y=~Defects_Number, color=~Description, text = ~Description,  type="bar") %>% 
        
        layout(yaxis = list(title = 'Count'), xaxis = list(title = ""), barmode = 'stack',
               title = 'Defects over Time',
               legend = list(orientation = "h"))  %>%
      
        config(displaylogo = FALSE) %>%
        config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))

      P

    }

  })
  
  
    
  
  #----------------------------- Summary tab -----------------------
  

  output$sum_act_table <- DT::renderDataTable({

    if (length(rea_act$out_act) > 0) {

    cols = c( "inx", "Station", "Act_Name", "Stroke", "var" )
    tmp = rea_act$out_act
    tmp = unique(tmp[, cols])
    tmp = tmp[order(tmp$inx), ]
    tmp$var_abs = abs(tmp$var)



    brks <- tmp$var_abs
    brks <- seq(0, 1000, 100)
    clrs <- round(seq(255, 40, length.out = length(brks) + 1 ), 0) %>%
      { paste0("rgb(255,", ., ",", ., ")") }

    DT::datatable(tmp, rownames = FALSE, selection = list(mode = 'none'),
                  options = list(paging = FALSE, scrollY = "200px",  #lengthMenu = c(10, 50, 100, 500),  pageLength = 10,
                                 dom = 'Brtip',  deferRender = TRUE,  scroller = TRUE
                  )) %>%
                    formatStyle( 'var_abs', target = 'row', backgroundColor = styleInterval(brks, clrs)   )
    }
  })

  
  output$out_act_text = renderText({

    if (length(rea_act$out_act) > 0) {
       ('Significant Actuation changes based on loaded history: ')
    } else {
      ('')
    }
  })  
    
  

  output$plot_qua_sum <- renderPlotly({

    if (length(rea_sum$qua) > 0) {

    tmp = rea_sum$qua

    p <- plot_ly(data = tmp, x = ~date)    %>%
          add_trace(y = ~(good_parts + bad_parts), 
                    line = list(color = 'rgb(120, 120, 120)', width = 1), 
                    marker = list(color = 'rgb(120, 120, 120)', size=4),
                    type = 'scatter', name = 'Total parts', yaxis = "y2", mode = 'lines+markers') %>%
          add_trace(y = ~quality, name = 'Quality, %', type = 'scatter', mode = 'lines+markers') %>%
          layout(yaxis2 = list(title = "Total parts", overlaying = "y", side = "right", automargin = T),
                 yaxis = list(title = "Quality, %"),  xaxis = list(title = ""),
                  title = 'Quality and Total parts over Time',
                 legend = list(orientation = "h", xanchor = "center", x = 0.5) ) %>%

        config(displaylogo = FALSE) %>%
        config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
    p

    }

  })
  
  
  output$plot_defect_sum <- renderPlotly({
    
    df = rea_sum$day_decode
    if (length(df) > 0) {
      
      P <- plot_ly(data = df)
      for(d in as.vector(unique(df$Description))) {
        ds <- df %>% filter(Description == d) 

        P <- add_trace(P, y =~Defects_Number, x =~date,  data = ds,  text = d,
                       type ="bar",  name = d, color = ~Description)
      }
      P <- layout(P, yaxis = list(title = 'Count'), xaxis = list(title = ""), barmode = 'stack',
                  title = 'Defects over Time',
                  showlegend = FALSE) %>% #legend = list(orientation = "h"))  %>%
      
      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
      
      P

    }
    
  })
  
  
  output$plot_fault_sum <- renderPlotly({
    
    tmp = rea_sum$day_fault
    if (is.null(tmp)) return()
    
    tmp$Descr = substr(tmp$Description, start = 1, stop = 40)
    
    P = plot_ly(data = tmp, x=~date, y=~Faults_Number, 
                color=~Descr, text = ~Description,  type="bar") %>% 
      
      layout(yaxis = list(title = 'Count'), xaxis = list(title = ""), barmode = 'stack',
             title = 'Faults over Time', showlegend = FALSE) %>%

      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
    
    P
  }) 
   

  
  
  output$plot_ateq_sum <- renderPlotly({
    
    tmp = rea_sum$day_ateq
    if (is.null(tmp)) return()
    

    p <- plot_ly(data = tmp, x = ~date)    %>%
      add_trace(y = ~Leak_SD,
                line = list(color = 'rgb(120, 120, 120)', width = 1),
                marker = list(color = 'rgb(120, 120, 120)', size=4),
                type = 'scatter', name = 'Leak_SD', yaxis = "y2", mode = 'lines+markers') %>%
      add_trace(y = ~Leak, name = 'Leak', type = 'scatter', mode = 'lines+markers') 
    

    vname2 = 'S111AteqLeak'  
    limy = specs %>% filter(Name == vname2) %>% select(Value_min, Value_max)
    
    lines = list()
    if (nrow(limy) > 0) {
      
      x0 = min(tmp$date)
      x1 = max(tmp$date) 
      
      lines = list(list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[1]), y1=as.numeric(limy[1]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymin'),
                   
                   list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[2]), y1=as.numeric(limy[2]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymax')
      )
    }

        
    p <- p %>% layout( 
                yaxis2 = list(title = "Leak_SD", overlaying = "y", side = "right", automargin = T),
                yaxis = list(title = "Leak"),  
                xaxis = list(title = ""),
                title = 'Leak daily averages over Time',
                legend = list(orientation = "h", xanchor = "center", x = 0.5, y = -0.3), shapes = lines ) %>%
      
      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
    
  })  
  

  
  output$plot_fta_sum <- renderPlotly({
    
    tmp = rea_sum$day_ateq
    if (is.null(tmp)) return()
    
    
    p <- plot_ly(data = tmp, x = ~date)    %>%
      add_trace(y = ~Flow_SD,
                line = list(color = 'rgb(120, 120, 120)', width = 1),
                marker = list(color = 'rgb(120, 120, 120)', size=4),
                type = 'scatter', name = 'Flow_SD', yaxis = "y2", mode = 'lines+markers') %>%
      add_trace(y = ~Flow, name = 'Flow', type = 'scatter', mode = 'lines+markers')
    
    
    vname2 = 'S101VacuumSideFlowResults'  
    limy = specs %>% filter(Name == vname2) %>% select(Value_min, Value_max)
    
    lines = list()
    if (nrow(limy) > 0) {
      
      x0 = min(tmp$date)
      x1 = max(tmp$date) 
      
      lines = list(list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[1]), y1=as.numeric(limy[1]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymin'),
                   
                   list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[2]), y1=as.numeric(limy[2]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymax')
      )
    }
    
      p <- p %>% layout( 
        yaxis2 = list(title = "Flow_SD", overlaying = "y", side = "right", automargin = T),
        yaxis = list(title = "Flow"),  
        xaxis = list(title = ""),
        title = 'Flow daily averages over Time',
        legend = list(orientation = "h", xanchor = "center", x = 0.5, y = -0.3), shapes = lines ) %>%
      
      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
    
  })    
  
  
  
  
   #----------------------------- Defects tab -----------------------
   
   
   observeEvent(input$BatchNo_def_input, {
     if (exists('df_parts_ag')) {

       tmp = df_parts_ag %>% filter(BatchMoNumber %in% input$BatchNo_def_input)

       x <- sort(as.vector(unique(tmp$BatchLotNumber)))
       updatePickerInput(session, "BatchLot_def_input",  selected = x  )

       # x <- sort(as.vector(unique(tmp[['PartNumber']])))
       #updatePickerInput(session, "PartNumber_def_input",  selected = x  )
     }
   }, ignoreNULL = FALSE)

  
  observeEvent(input$BatchLot_def_input, {
    if (exists('df_parts_ag')) {

      tmp = df_parts_ag %>% filter(BatchLotNumber %in% input$BatchLot_def_input)

      x <- sort(as.vector(unique(tmp$BatchMoNumber)))
      updatePickerInput(session, "BatchNo_def_input",  selected = x  )

     # x <- sort(as.vector(unique(tmp[['PartNumber']])))
     # updatePickerInput(session, "PartNumber_def_input",  selected = x  )
    }
  }, ignoreNULL = FALSE)
  
  
  observeEvent(input$PartNumber_def_input, {
    if (exists('df_parts_ag')) {

      tmp = df_parts_ag %>% filter(PartNumber %in% input$PartNumber_def_input)

      x <- sort(as.vector(unique(tmp$BatchMoNumber)))
      updatePickerInput(session, "BatchNo_def_input",  selected = x  )
       
      x <- sort(as.vector(unique(tmp$BatchLotNumber)))
      updatePickerInput(session, "BatchLot_def_input",  selected = x  )
    }
  }, ignoreNULL = FALSE)
  
  
  
   
   observeEvent( input$calc_def, {
     
     if (check_df('df_parts_ag', mes=1) < 0) {return()}
     
     withProgress({
       
       setProgress(message = "Defects data loading...")
       incProgress(0.5, detail = paste("step ", 1))
       
     
      isolate({  
        tmp <- df_parts_ag %>%   
        filter(BatchMoNumber %in% input$BatchNo_def_input,
               BatchLotNumber %in% input$BatchLot_def_input,
               PartNumber %in% input$PartNumber_def_input)   %>%
              group_by(date) %>%
              summarize(good_parts = sum(good_parts), bad_parts = sum(bad_parts)) %>%
              mutate(quality = good_parts / (good_parts + bad_parts) * 100,
                     totp = good_parts + bad_parts)

        rea_def$qua <- tmp
        rea_def$date_sel <- NULL
        rea_def$hr_sel <- NULL
        
        
        rea_def$def_hr  <- def_decode %>%  filter(BatchMoNumber %in% input$BatchNo_def_input,
                                                  BatchLotNumber %in% input$BatchLot_def_input,
                                                  PartNumber %in% input$PartNumber_def_input) %>%
                                          mutate(date = as.Date(StartTime), 
                                          hour = format(as.POSIXct(StartTime, format="%Y-%m-%d %H:%M:%S"),"%H") ) %>% 
          group_by(date, hour, Description) %>%
          summarize(Defects_Number = n() )    
        
        
        cols = c("StartTime",  "EndTime",  "BatchMoNumber", "BatchLotNumber",  "Station", "Description")
        
        rea_def$def  <- def_decode %>%  filter(BatchMoNumber %in% input$BatchNo_def_input,
                                               BatchLotNumber %in% input$BatchLot_def_input,
                                               PartNumber %in% input$PartNumber_def_input) %>% select(cols) %>%
          mutate(date = as.Date(StartTime), 
                 hour = format(as.POSIXct(StartTime, format="%Y-%m-%d %H:%M:%S"),"%H") ) 
        

        }) 
      
      setProgress(message = "Done.")
      incProgress(1.0, detail = paste("step ", 2))
     })
      
   })
   
   

   output$plot_qua_def <- renderPlotly({
     
     
     if (is.null(rea_def$qua)) return()
       
       tmp = rea_def$qua
       
       p <- plot_ly(data = tmp, x = ~date, source = "plot_qua_def")    %>%
         add_trace(y = ~totp,
                   line = list(color = 'rgb(120, 120, 120)', width = 1),
                   marker = list(color = 'rgb(120, 120, 120)', size=4),
                   type = 'scatter', name = 'Total parts', yaxis = "y2", mode = 'lines+markers') %>%
         add_trace(y = ~quality, name = 'Quality, %', type = 'scatter', mode = 'lines+markers') %>%
         layout( 
                yaxis2 = list(title = "Total parts", overlaying = "y", side = "right", automargin = T),
                yaxis = list(title = "Quality, %"),  
                xaxis = list(title = ""),
                title = 'Quality and Total parts over Time',
                legend = list(orientation = "h", xanchor = "center", x = 0.5, y = -0.3) ) %>%

         config(displaylogo = FALSE) %>%
         config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
         p
         
   })
   
   
   observeEvent(event_data("plotly_click", source = "plot_qua_def"), {
     
     rea_def$date_sel <-  event_data("plotly_click", source = "plot_qua_def")$x
     rea_def$hr_sel <- NULL
     
   })      
   
   
   
   
   output$plot_defect_def <- renderPlotly({
     
     if (is.null(rea_def$date_sel)) return()
     
       tmp <- rea_def$def_hr  %>%
         filter(date %in% as.Date(rea_def$date_sel)) 

       P <- plot_ly(data = tmp, source = "plot_defect_def")
       for(d in as.vector(unique(tmp$Description))) {
         ds <- tmp %>% filter(Description == d) 
         
         P <- add_trace(P, y =~Defects_Number, x =~hour,  data = ds,  text = d,
                        type ="bar",  name = d, color = ~Description
                        )
       }
       P <- layout(P, yaxis = list(title = 'Count'), xaxis = list(title = ""), barmode = 'stack',
                   legend = list(orientation = "h"), 
                    title = paste(rea_def$date_sel,  ': defects by hours'))  %>%
         
         config(displaylogo = FALSE) %>%
         config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
       
       P

   })

   observeEvent(event_data("plotly_click", source = "plot_defect_def"), {
     
     rea_def$hr_sel <-  event_data("plotly_click", source = "plot_defect_def")$x
     
   })      
   
   
   output$table_def <- DT::renderDataTable({
     
     if (is.null(rea_def$date_sel)) return()
     if (is.null(rea_def$hr_sel)) return()

     tmp <- rea_def$def  %>%
       filter(date %in% as.Date(rea_def$date_sel)) %>% filter(hour %in% rea_def$hr_sel)  #%>%   select(cols)
     
     DT::datatable(tmp, filter = 'top', rownames = FALSE, selection = "none", #extensions = c('Buttons', 'Scroller'),
                   options = list(lengthMenu = c(10, 50, 100, 500),  pageLength = 10,
                                  dom = 'Bfrtip',  deferRender = TRUE
                                  # scroller = TRUE, buttons = c('copy', 'csv', 'excel')
                   ))
   })
   

   observeEvent(rea_def$hr_sel, {
     
     shinyjs::hide("exp_def")
     if(!is.null(rea_def$hr_sel))  shinyjs::show("exp_def")
     
   }, ignoreNULL = FALSE)   
      
   
   
   output$exp_def <- downloadHandler(

     filename = function() { "defects.xlsx" },
     
     content = function(file) {
        
       if (is.null(rea_def$date_sel)) return()
       if (is.null(rea_def$hr_sel)) return()       
              
       tempFile <- tempfile(fileext = ".xlsx")

       tmp <- rea_def$def  %>%
         filter(date %in% as.Date(rea_def$date_sel)) %>% filter(hour %in% rea_def$hr_sel)        

       
       s = 'data'
       eval(parse(text =  paste0('write_xlsx(list(', s, ' = tmp), tempFile)')))
       file.rename(tempFile, file)
       
     }
   )
   
   #----------------------------- Faults tab -----------------------
   
   
   observeEvent(input$Station_flt_input, {
     if (exists('df_faults')) {
       
       tmp = df_faults %>% filter(Station %in% input$Station_flt_input)
       
       x <- sort(as.vector(unique(tmp$Description)))
       updatePickerInput(session, "Descr_flt_input",   choices = x, selected = x  )
       
     }
   }, ignoreNULL = FALSE)
   
   

   
   
   observeEvent( input$calc_flt, {
     
     if (check_df('df_faults', mes=1) < 0) {return()}
     
     withProgress({
       
       setProgress(message = "Faults data loading...")
       incProgress(0.5, detail = paste("step ", 1))
       
       
       isolate({  
         
         tmp <- df_faults %>%   
           filter(Station %in% input$Station_flt_input,
                  Description %in% input$Descr_flt_input  )  %>%
           mutate(date = as.Date(Time), 
                  hour = format(as.POSIXct(Time, format="%Y-%m-%d %H:%M:%S"),"%H") )          
         
         
         rea_flt$date_agg <- tmp %>%   group_by(date) %>%  summarize(Faults_Number = n() )
         
         rea_flt$date_sel <- NULL
         rea_flt$hr_sel <- NULL
         
         rea_flt$flt_hr  <- tmp %>%  group_by(date, hour, Description) %>%   summarize(Faults_Number = n() )    
         
         
         rea_flt$flt <- tmp
         
         
       }) 
       
       setProgress(message = "Done.")
       incProgress(1.0, detail = paste("step ", 2))
     })
     
   })
   
   
   
   output$plot_day_flt <- renderPlotly({

     if (is.null(rea_flt$date_agg)) return()

     tmp = rea_flt$date_agg

     p <- plot_ly(data = tmp, x = ~date, source = "plot_day_flt")    %>%
       add_trace(y = ~Faults_Number,
                 type = 'scatter', name = 'Total parts',  mode = 'lines+markers') %>%
       layout(
         yaxis = list(title = "Faults Number"),
         xaxis = list(title = ""),
         title = 'Faults Number over Time',
         legend = list(orientation = "h", xanchor = "center", x = 0.5, y = -0.3) ) %>%

       config(displaylogo = FALSE) %>%
       config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
     p

   })
   
   
   observeEvent(event_data("plotly_click", source = "plot_day_flt"), {

     rea_flt$date_sel <-  event_data("plotly_click", source = "plot_day_flt")$x
     rea_flt$hr_sel <- NULL

   })



   output$plot_hour_flt <- renderPlotly({

     if (is.null(rea_flt$date_sel)) return()

     tmp <- rea_flt$flt_hr  %>%
       filter(date %in% as.Date(rea_flt$date_sel))
     tmp$Descr = substr(tmp$Description, start = 1, stop = 40)
       
     P = plot_ly(data = tmp, x=~hour, y=~Faults_Number, source = "plot_hour_flt", 
                 color=~Descr, text = ~Description,  type="bar") %>% 
       
       layout(yaxis = list(title = 'Count'), xaxis = list(title = ""), barmode = 'stack',
              title = paste(rea_flt$date_sel,  ': faults by hours'),
              legend = list(orientation = "h"))  %>%     
     
       config(displaylogo = FALSE) %>%
       config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))

     P

   })

   
   observeEvent(event_data("plotly_click", source = "plot_hour_flt"), {

     rea_flt$hr_sel <-  event_data("plotly_click", source = "plot_hour_flt")$x

   })


   output$table_flt <- DT::renderDataTable({

     if (is.null(rea_flt$date_sel)) return()
     if (is.null(rea_flt$hr_sel)) return()

     tmp <- rea_flt$flt  %>%
       filter(date %in% as.Date(rea_flt$date_sel)) %>% filter(hour %in% rea_flt$hr_sel) 

     DT::datatable(tmp, filter = 'top', rownames = FALSE, selection = "none", 
                   options = list(lengthMenu = c(10, 50, 100, 500),  pageLength = 10,
                                  dom = 'Bfrtip',  deferRender = TRUE
                   ))
   })


   observeEvent(rea_flt$hr_sel, {

     shinyjs::hide("exp_flt")
     if(!is.null(rea_flt$hr_sel))  shinyjs::show("exp_flt")

   }, ignoreNULL = FALSE)



   output$exp_flt <- downloadHandler(

     filename = function() { "faults.xlsx" },

     content = function(file) {

       if (is.null(rea_flt$date_sel)) return()
       if (is.null(rea_flt$hr_sel)) return()

       tempFile <- tempfile(fileext = ".xlsx")

       tmp <- rea_flt$flt  %>%
         filter(date %in% as.Date(rea_flt$date_sel)) %>% filter(hour %in% rea_flt$hr_sel)


       s = 'data'
       eval(parse(text =  paste0('write_xlsx(list(', s, ' = tmp), tempFile)')))
       file.rename(tempFile, file)

     }
   )
   

   
  
  #----------------------------- ATEQ tab -----------------------
  

   observeEvent(input$BatchNo_ateq_input, {
     if (exists('df_ateq')) {
       
       tmp = df_ateq %>% filter(BatchMoNumber %in% input$BatchNo_ateq_input)
       
       x <- sort(as.vector(unique(tmp$BatchLotNumber)))
       updatePickerInput(session, "BatchLot_ateq_input",  selected = x  )
       
     }
   }, ignoreNULL = FALSE)
   
   
   observeEvent(input$BatchLot_ateq_input, {
     if (exists('df_ateq')) {
       
       tmp = df_ateq %>% filter(BatchLotNumber %in% input$BatchLot_ateq_input)
       
       x <- sort(as.vector(unique(tmp$BatchMoNumber)))
       updatePickerInput(session, "BatchNo_ateq_input",  selected = x  )
       
     }
   }, ignoreNULL = FALSE)
   
   
   observeEvent(input$Station_ateq_input, {
     if (exists('df_ateq')) {

       tmp = df_ateq %>% filter(Station %in% input$Station_ateq_input)

       x <- sort(as.vector(unique(tmp$BatchMoNumber)))
       updatePickerInput(session, "BatchNo_ateq_input",  selected = x  )

       x <- sort(as.vector(unique(tmp$BatchLotNumber)))
       updatePickerInput(session, "BatchLot_ateq_input",  selected = x  )
     }
   }, ignoreNULL = FALSE)
   
   
   
   
  
  observeEvent( input$calc_ateq, {


    if (check_df('df_ateq', mes=1) < 0) return()


    withProgress({
      
      setProgress(message = "ATEQ data preparation...")
      incProgress(0.5, detail = paste("step ", 1))
      

      isolate({  
        tmp <- df_ateq %>%  filter(BatchMoNumber %in% input$BatchNo_ateq_input,
                                   BatchLotNumber %in% input$BatchLot_ateq_input,
                                   Station %in% input$Station_ateq_input) 
        rea_ateq$raw  <- tmp
        
        rea_ateq$date_agg <- tmp  %>% mutate(Leak_SD = Leak)  %>%
          group_by(date) %>%
          summarize( Leak = mean(Leak), Leak_SD = sd(Leak_SD))
         
  
        rea_ateq$date_sel <- NULL
        rea_ateq$brush <- NULL
        rea_ateq$date_raw <- NULL      
  
      })
  
      setProgress(message = "Done")
      incProgress(0.9, detail = paste("step ", 2))   
    })  
    
        
  })
    

    


  output$plot_ateq_day <- renderPlotly({
    
    if (is.null(rea_ateq$date_agg)) return()
    
    tmp = rea_ateq$date_agg
    
    p <- plot_ly(data = tmp, x = ~date, source = "plot_ateq_day")    %>%
      add_trace(y = ~Leak_SD,
                line = list(color = 'rgb(120, 120, 120)', width = 1),
                marker = list(color = 'rgb(120, 120, 120)', size=4),
                type = 'scatter', name = 'Leak_SD', yaxis = "y2", mode = 'lines+markers') %>%
      add_trace(y = ~Leak, name = 'Leak', type = 'scatter', mode = 'lines+markers')
    
    
    vname2 = 'S111AteqLeak'  
    limy = specs %>% filter(Name == vname2) %>% select(Value_min, Value_max)
    
    lines = list()
    if (nrow(limy) > 0) {
      
          x0 = min(tmp$date)
          x1 = max(tmp$date) 
          
          lines = list(list(type='line', x0 = x0, x1 = x1, 
                            y0=as.numeric(limy[1]), y1=as.numeric(limy[1]),
                            line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymin'),
                       
                       list(type='line', x0 = x0, x1 = x1, 
                            y0=as.numeric(limy[2]), y1=as.numeric(limy[2]),
                            line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymax')
          )
    }    
    
    
    p <- p %>%  layout( 
            yaxis2 = list(title = "Leak_SD", overlaying = "y", side = "right", automargin = T),
            yaxis = list(title = "Leak"),  
            xaxis = list(title = ""),
            title = 'Leak daily averages over Time',
            legend = list(orientation = "h", xanchor = "center", x = 0.5, y = -0.3), shapes = lines ) %>%
      
      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))

  })  
  
   
  
  observeEvent(event_data("plotly_click", source = "plot_ateq_day"), {
    
    rea_ateq$date_sel <-  event_data("plotly_click", source = "plot_ateq_day")$x
    rea_ateq$brush <- NULL
    rea_ateq$date_raw <- NULL
    
  })      
  
  
  observeEvent(event_data("plotly_brushed", source = "plot_ateq_scatt"), {
    
    rea_ateq$brush <-  event_data("plotly_brushed", source = "plot_ateq_scatt")
    
   
  })        
  
  
  output$plot_ateq_scatt <- renderPlotly({
    
    d = rea_ateq$date_sel
    if (is.null(d)) return()

    
    rea_ateq$date_raw  <- rea_ateq$raw  %>%  filter(date %in% as.Date(d))

    
    p <- plot_ly(data = rea_ateq$date_raw,  source = "plot_ateq_scatt", type = 'scatter', mode = 'markers',
                 x = ~SerialNumber, y = ~Leak, color = ~BatchMoNumber, text = ~BatchMoNumber) 

        
    vname2 = 'S111AteqLeak'  
    limy = specs %>% filter(Name == vname2) %>% select(Value_min, Value_max)

    lines = list()
    if (nrow(limy) > 0) {
      
      tmp = rea_ateq$date_raw
      x0 = min(tmp$SerialNumber)
      x1 = max(tmp$SerialNumber) 
      
      lines = list(list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[1]), y1=as.numeric(limy[1]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymin'),
                   
                   list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[2]), y1=as.numeric(limy[2]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymax')
      )
    }
    
      
     p <- p %>% layout(yaxis = list(title = 'Leak'), xaxis = list(title = "Serial Number"),
                  title = paste0('ATEQ measurements: ', d), dragmode = "select", shapes = lines)  %>%
      
      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c( "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
    
    
    
  })  
  
  

  output$table_ateq_raw <- DT::renderDataTable({
    
    brush = rea_ateq$brush
   
    if (is.null(brush)) return()

     
    tmp <- rea_ateq$date_raw %>%
       filter(between(SerialNumber, brush$x[1], brush$x[2]),
              between(Leak, brush$y[1], brush$y[2])) #%>%


    DT::datatable(tmp, filter = 'top', rownames = FALSE, selection = "none",
                    options = list(lengthMenu = c(10, 50, 100, 500),  pageLength = 10,
                                   dom = 'Bfrtip',  deferRender = TRUE) )

  })

  
  observeEvent(rea_ateq$brush, {
    
    shinyjs::hide("exp_ateq")
    if(!is.null(rea_ateq$brush))  shinyjs::show("exp_ateq")
    
  }, ignoreNULL = FALSE)  
    
  
  
  output$exp_ateq <- downloadHandler(
    
    filename = function() { "ateq_fta.xlsx" },
    
    content = function(file) {
      
      if (is.null(rea_ateq$date_raw)) return()
      if (is.null(rea_ateq$brush)) return()       
      
      brush <- rea_ateq$brush
      
      tempFile <- tempfile(fileext = ".xlsx")
      
      tmp <- rea_ateq$date_raw %>%
        filter(between(SerialNumber, brush$x[1], brush$x[2]),
               between(Leak, brush$y[1], brush$y[2]))      
      
      
      s = 'data'
      eval(parse(text =  paste0('write_xlsx(list(', s, ' = tmp), tempFile)')))
      file.rename(tempFile, file)
      
    }
  )
  
  
  
  
#----------------------------- FTA tab -----------------------
  
    
  observeEvent(input$BatchNo_fta_input, {
    if (exists('df_ateq')) {
      
      tmp = df_ateq %>% filter(BatchMoNumber %in% input$BatchNo_fta_input)
      
      x <- sort(as.vector(unique(tmp$BatchLotNumber)))
      updatePickerInput(session, "BatchLot_fta_input",  selected = x  )
      
    }
  }, ignoreNULL = FALSE)
  
  
  observeEvent(input$BatchLot_fta_input, {
    if (exists('df_ateq')) {
      
      tmp = df_ateq %>% filter(BatchLotNumber %in% input$BatchLot_fta_input)
      
      x <- sort(as.vector(unique(tmp$BatchMoNumber)))
      updatePickerInput(session, "BatchNo_fta_input",  selected = x  )
      
    }
  }, ignoreNULL = FALSE)
  
  
  observeEvent(input$Station_fta_input, {
    if (exists('df_ateq')) {
      
      tmp = df_ateq %>% filter(Station %in% input$Station_fta_input)
      
      x <- sort(as.vector(unique(tmp$BatchMoNumber)))
      updatePickerInput(session, "BatchNo_fta_input",  selected = x  )
      
      x <- sort(as.vector(unique(tmp$BatchLotNumber)))
      updatePickerInput(session, "BatchLot_fta_input",  selected = x  )
    }
  }, ignoreNULL = FALSE)
  
  
  
  
  
  observeEvent( input$calc_fta, {


    if (check_df('df_ateq', mes=1) < 0) return()


    withProgress({

      setProgress(message = "FTA data preparation...")
      incProgress(0.5, detail = paste("step ", 1))


      isolate({
        tmp <- df_ateq %>%  filter(BatchMoNumber %in% input$BatchNo_fta_input,
                                   BatchLotNumber %in% input$BatchLot_fta_input,
                                   Station %in% input$Station_fta_input)
        rea_fta$raw  <- tmp

        rea_fta$date_agg <- tmp  %>% mutate(Flow_SD = Flow)  %>%
          group_by(date) %>%
          summarize( Flow = mean(Flow), Flow_SD = sd(Flow_SD))


        rea_fta$date_sel <- NULL
        rea_fta$brush <- NULL
        rea_fta$date_raw <- NULL

      })

      setProgress(message = "Done")
      incProgress(0.9, detail = paste("step ", 2))
    })


  })





  output$plot_fta_day <- renderPlotly({

    if (is.null(rea_fta$date_agg)) return()

    tmp = rea_fta$date_agg

    p <- plot_ly(data = tmp, x = ~date, source = "plot_fta_day")    %>%
      add_trace(y = ~Flow_SD,
                line = list(color = 'rgb(120, 120, 120)', width = 1),
                marker = list(color = 'rgb(120, 120, 120)', size=4),
                type = 'scatter', name = 'Flow_SD', yaxis = "y2", mode = 'lines+markers') %>%
      add_trace(y = ~Flow, name = 'Flow', type = 'scatter', mode = 'lines+markers') 
    
    
    vname2 = 'S101VacuumSideFlowResults'  
    limy = specs %>% filter(Name == vname2) %>% select(Value_min, Value_max)
    
    lines = list()
    if (nrow(limy) > 0) {
      
      x0 = min(tmp$date)
      x1 = max(tmp$date) 
      
      lines = list(list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[1]), y1=as.numeric(limy[1]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymin'),
                   
                   list(type='line', x0 = x0, x1 = x1, 
                        y0=as.numeric(limy[2]), y1=as.numeric(limy[2]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymax')
      )
    }        
    
      p <- p %>% layout(
        yaxis2 = list(title = "Flow_SD", overlaying = "y", side = "right", automargin = T),
        yaxis = list(title = "Flow"),
        xaxis = list(title = ""),
        title = 'Flow daily averages over Time',
        legend = list(orientation = "h", xanchor = "center", x = 0.5, y = -0.3), shapes = lines ) %>%

      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))

  })



  observeEvent(event_data("plotly_click", source = "plot_fta_day"), {

    rea_fta$date_sel <-  event_data("plotly_click", source = "plot_fta_day")$x
    rea_fta$brush <- NULL
    rea_fta$date_raw <- NULL

  })


  observeEvent(event_data("plotly_brushed", source = "plot_fta_scatt"), {

    rea_fta$brush <-  event_data("plotly_brushed", source = "plot_fta_scatt")


  })


  output$plot_fta_scatt <- renderPlotly({

    d = rea_fta$date_sel
    if (is.null(d)) return()


    rea_fta$date_raw  <- rea_fta$raw  %>%  filter(date %in% as.Date(d))


    p <- plot_ly(data = rea_fta$date_raw,  source = "plot_fta_scatt", type = 'scatter', mode = 'markers',
                 x = ~SerialNumber, y = ~Flow, color = ~BatchMoNumber, text = ~BatchMoNumber)


    vname2 = 'S101VacuumSideFlowResults'
    limy = specs %>% filter(Name == vname2) %>% select(Value_min, Value_max)

    lines = list()
    if (nrow(limy) > 0) {

      tmp = rea_fta$date_raw
      x0 = min(tmp$SerialNumber)
      x1 = max(tmp$SerialNumber)

      lines = list(list(type='line', x0 = x0, x1 = x1,
                        y0=as.numeric(limy[1]), y1=as.numeric(limy[1]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymin'),

                   list(type='line', x0 = x0, x1 = x1,
                        y0=as.numeric(limy[2]), y1=as.numeric(limy[2]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymax')
      )
    }


    p <- p %>% layout(yaxis = list(title = 'Flow'), xaxis = list(title = "Serial Number"),
                      title = paste0('FTA measurements: ', d), dragmode = "select", shapes = lines)  %>%

      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c( "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))



  })



  output$table_fta_raw <- DT::renderDataTable({

    brush = rea_fta$brush

    if (is.null(brush)) return()


    tmp <- rea_fta$date_raw %>%
      filter(between(SerialNumber, brush$x[1], brush$x[2]),
             between(Flow, brush$y[1], brush$y[2])) #%>%


    DT::datatable(tmp, filter = 'top', rownames = FALSE, selection = "none",
                  options = list(lengthMenu = c(10, 50, 100, 500),  pageLength = 10,
                                 dom = 'Bfrtip',  deferRender = TRUE) )

  })


  observeEvent(rea_fta$brush, {

    shinyjs::hide("exp_fta")
    if(!is.null(rea_fta$brush))  shinyjs::show("exp_fta")

  }, ignoreNULL = FALSE)



  output$exp_fta <- downloadHandler(

    filename = function() { "ateq_fta.xlsx" },

    content = function(file) {

      if (is.null(rea_fta$date_raw)) return()
      if (is.null(rea_fta$brush)) return()

      brush <- rea_fta$brush

      tempFile <- tempfile(fileext = ".xlsx")

      tmp <- rea_fta$date_raw %>%
        filter(between(SerialNumber, brush$x[1], brush$x[2]),
               between(Flow, brush$y[1], brush$y[2]))


      s = 'data'
      eval(parse(text =  paste0('write_xlsx(list(', s, ' = tmp), tempFile)')))
      file.rename(tempFile, file)

    }
  )
  
  
  
  #----------------------------- Custom tab -----------------------
  
  # Time_cust_input
  # BatchNo_cust_input
  # Var1_cust_input
  # Var2_cust_input
  
  
  observeEvent( input$calc_cust, {
    
    if (is.null(input$Var1_cust_input)) {return()}
    if (is.null(input$Var2_cust_input)) {return()}
    

    withProgress({
      
      setProgress(message = "Custom data loading...")
      incProgress(0.5, detail = paste("step ", 1))
      
      
      vname1 = input$Var1_cust_input
      vname2 = input$Var2_cust_input
      

      st_sql = paste("select StartTime, EndTime, BatchSerialNumber, BatchMoNumber, BatchLotNumber, ", 
                      vname1, ", ", vname2, " from DataPart 
                     where StartTime >= '",  rea_times$starttime,  "' and EndTime < '", rea_times$endtime, "' 
                     and (", vname1, " >0 or ", vname2, " >0 ) ")

      df_cust <<- get_sql(st_sql, conn)
       


      isolate({  
        tmp <- df_cust %>%  filter(BatchMoNumber %in% input$BatchNo_cust_input) %>%
                mutate(date = as.Date(StartTime) )
        rea_cust$raw  <- tmp
        
        tmp <- tmp  %>% mutate(x = !!as.name(vname1), y = (!!as.name(vname2)) )  %>%
          group_by(date) %>%
          summarize( x = mean(x), y = mean(y))
        
        colnames(tmp) <- c('date', vname1, vname2)
        
        rea_cust$date_agg <- tmp 
        rea_cust$date_sel <- NULL
        rea_cust$brush <- NULL
        rea_cust$date_raw <- NULL      

      })      
      
      rea_cust$vname1 = vname1
      rea_cust$vname2 = vname2
      
      setProgress(message = "Done")
      incProgress(0.9, detail = paste("step ", 2))   
    })  
    
    
  })
  

  
  output$plot_cust_day <- renderPlotly({
    
    if (is.null(rea_cust$date_agg)) return()
    
    
    vname1 = rea_cust$vname1
    vname2 = rea_cust$vname2
    

    tmp = rea_cust$date_agg
    
    p <- plot_ly(data = tmp, x = ~date, source = "plot_cust_day")    %>%
      add_trace(y = ~get(vname1), name = vname1, yaxis = "y2", type = 'scatter', mode = 'lines+markers') %>%
                # line = list(color = 'rgb(120, 120, 120)', width = 1),
                # marker = list(color = 'rgb(120, 120, 120)', size=4),
                # type = 'scatter', name = vname1, yaxis = "y2", mode = 'lines+markers') %>%
      add_trace(y = ~(get(vname2)), name = vname2, type = 'scatter', mode = 'lines+markers') %>%
      
      layout( 
        yaxis2 = list(title = vname1, overlaying = "y", side = "right", automargin = T),
        yaxis = list(title = vname2),  
        xaxis = list(title = ""),
        title = 'Daily averages of the selected measurements',
        legend = list(orientation = "h", xanchor = "center", x = 0.5, y = -0.3) ) %>%

        
      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
    
  })  
  
  
   # daily click
  observeEvent(event_data("plotly_click", source = "plot_cust_day"), {

    rea_cust$date_sel <-  event_data("plotly_click", source = "plot_cust_day")$x
    rea_cust$brush <- NULL
    rea_cust$date_raw <- NULL

  })


  observeEvent(event_data("plotly_brushed", source = "plot_cust_scatt"), {

    rea_cust$brush <-  event_data("plotly_brushed", source = "plot_cust_scatt")
    
  })
   
   
  output$plot_cust_scatt <- renderPlotly({

    d = rea_cust$date_sel
    if (is.null(d)) return()

    vname1 = rea_cust$vname1
    vname2 = rea_cust$vname2   
    

    rea_cust$date_raw  <- rea_cust$raw  %>%  filter(date %in% as.Date(d))
    tmp <- rea_cust$date_raw

    p <- plot_ly(data = tmp,  source = "plot_cust_scatt", type = 'scatter', mode = 'markers',
            x = ~get(vname1), y = ~get(vname2), color = ~BatchMoNumber, text = ~BatchMoNumber) 


    limx = specs %>% filter(Name == vname1) %>% select(Value_min, Value_max)
    limy = specs %>% filter(Name == vname2) %>% select(Value_min, Value_max)


    lines = list()
    if (nrow(limy) > 0) {

      # p <- p %>%
      #   add_trace(x = c(x1),
      #             y = c(mean(ds1$hmean)+offset),
      #             mode = 'text',  text = c('historical mean'),
      #             type = 'scatter', showlegend = FALSE,
      #             textfont = list(color = 'steelblue', size = 12)
      #   )

      lines = list(list(type='line', x0 = min(tmp[vname1]), x1 = max(tmp[vname1]), 
                        y0=as.numeric(limy[1]), y1=as.numeric(limy[1]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymin'),

                   list(type='line', x0 = min(tmp[vname1]), x1 = max(tmp[vname1]), 
                        y0=as.numeric(limy[2]), y1=as.numeric(limy[2]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'ymax'),
                   
                   list(type='line', y0 = min(tmp[vname2]), y1 = max(tmp[vname2]), 
                        x0=as.numeric(limx[1]), x1=as.numeric(limx[1]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'xmax'),
                   
                   list(type='line', y0 = min(tmp[vname2]), y1 = max(tmp[vname2]), 
                        x0=as.numeric(limx[2]), x1=as.numeric(limx[2]),
                        line=list(dash='dot', width=3, color = 'lightpink'),  name = 'xmax')                   
      )
    }

      p <- p %>%
      layout(yaxis = list(title = vname2), xaxis = list(title = vname1),
             title = paste0('2D data plot: ', d), dragmode = "select", shapes = lines)  %>%

      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c( "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))



  })
   
   
   
  output$table_cust_raw <- DT::renderDataTable({

    brush = rea_cust$brush
    vname1 = rea_cust$vname1
    vname2 = rea_cust$vname2       

    if (is.null(rea_cust$date_raw)) return()
    if (is.null(brush)) return()
    if (is.null(vname1)) return()
    if (is.null(vname2)) return()    

    tmp <- rea_cust$date_raw %>%
      filter(between(!!as.name(vname1), brush$x[1], brush$x[2]),
             between(!!as.name(vname2), brush$y[1], brush$y[2])) %>%

      
    DT::datatable( filter = 'top', rownames = FALSE, selection = "none",
                  options = list(lengthMenu = c(10, 50, 100, 500),  pageLength = 10,
                                 dom = 'Bfrtip',  deferRender = TRUE) )

  })




  observeEvent(rea_cust$brush, {

    shinyjs::hide("exp_cust")
    if(!is.null(rea_cust$brush))  shinyjs::show("exp_cust")

  }, ignoreNULL = FALSE)

  
      
  output$exp_cust <- downloadHandler(
    
    filename = function() { "custom.xlsx" },
    
    content = function(file) {
      
      if (is.null( rea_cust$date_raw)) return()
      if (is.null(rea_cust$brush)) return()       
      
      brush <- rea_cust$brush
      vname1 = rea_cust$vname1
      vname2 = rea_cust$vname2             
      
      tempFile <- tempfile(fileext = ".xlsx")
      
      tmp <- rea_cust$date_raw %>%
        filter(between(!!as.name(vname1), brush$x[1], brush$x[2]),
               between(!!as.name(vname2), brush$y[1], brush$y[2])) 

      s = 'data'
      eval(parse(text =  paste0('write_xlsx(list(', s, ' = tmp), tempFile)')))
      file.rename(tempFile, file)
      
    }
  )
  
  

  
    
#----------------------------- Actuation tab -----------------------

    
    observeEvent(input$Station_act_input, {
      if (exists('df_act')) {
        ix = which(df_act$Station == input$Station_act_input)
        ds = df_act[ix, ]    # filter by station
        
        x <- sort(as.vector(unique(ds$Act_Name)))
        updatePickerInput(session, "Actuation_act_input", choices = x  )
      }
    })
    
    

  observeEvent( input$calc_act, {

      withProgress({
        
        setProgress(message = "Actuation plot creating...")
        incProgress(0.3, detail = paste("step ", 1))    
        

        rea_act$ds <- isolate({
          df_act %>% filter(Station == input$Station_act_input,
                             Act_Name == input$Actuation_act_input,
                             Stroke == input$Stroke_act_input)
        })

        if (!is.null(rea_act$out_act)) {      
            rea_act$ds1 <- isolate({
              rea_act$out_act %>% filter(Station == input$Station_act_input,
                             Act_Name == input$Actuation_act_input,
                             Stroke == input$Stroke_act_input)
            })
        }
        
    })
  })      
    

  observeEvent(input$act_table_rows_selected, {
    
    if (nrow(rea_act$out_act) > 0) {
        i = input$act_table_rows_selected
        if (length(i) == 0) { i = 1 }
        rea_act$ds <- df_act %>% filter(inx == i)
        rea_act$ds1 <- rea_act$out_act %>% filter(inx == i)
    }
  })  
  

  

  output$plot_act <- renderPlotly({


      ds = rea_act$ds 
      ds1 = rea_act$ds1 
  
      if (is.null(ds) )  return() 
      if (nrow(ds) == 0) return()

      ds <- ds %>% arrange(DateCreated) 
      
      # loess smoothing
      tmp <- ds %>% mutate(date = DateCreated, val = Parameter_value)
      tmp <- tmp %>%  mutate(tt = as.numeric(difftime(date, date[1], units = "mins")) )
      ll.smooth = loess(val ~ tt, data=tmp, span=input$sliderLoess)
      tmp$smoothed = predict(ll.smooth)


      p <- plot_ly()    %>%
        add_trace(data = ds, x = ~DateCreated, y = ~Parameter_value, 
               #   line = list(color = 'rgb(120, 120, 120)', width = 1), 
               #   marker = list(color = 'rgb(120, 120, 120)', size=4),
                  type = 'scatter', name = 'Actual values', mode = 'lines+markers') %>%
        add_trace(data = tmp, x = ~date, y = ~smoothed, name = 'Approximation', type = 'scatter', mode = 'lines+markers') 
       
        lines = list()
        
        if (!is.null(ds1) ) {
          if (nrow(ds1) > 0) {
          
              ds1 <- ds1 %>% arrange(DateCreated )
              x0 = min(ds$DateCreated)
              x1 = max(ds$DateCreated)
              offset = 0.75
              
              p <- p %>% 
                add_trace(data = ds1, x = ~DateCreated, y = ~Parameter_value, 
                          type = 'scatter', name = 'Critival change', mode = 'markers',
                          marker = list(color = 'red', size=10))  %>%
              
              add_trace(x = c(x1, x1),
                        y = c(mean(ds1$sdmin)+offset, mean(ds1$sdmax)+offset),
                         mode = 'text',  text = c('SD range', 'SD range'),
                        type = 'scatter', showlegend = FALSE, 
                        textfont = list(color = 'lightskyblue', size = 12)
                        )          %>%     

              add_trace(x = c(x1, x1),
                        y = c(mean(ds1$qmin)+offset, mean(ds1$qmax)+offset),
                        mode = 'text',  text = c('IQR', 'IQR'),
                        type = 'scatter', showlegend = FALSE, 
                        textfont = list(color = 'lightpink', size = 12)
              )      %>%

                add_trace(x = c(x1),
                          y = c(mean(ds1$hmean)+offset),
                          mode = 'text',  text = c('historical mean'),
                          type = 'scatter', showlegend = FALSE, 
                          textfont = list(color = 'steelblue', size = 12)
                )               
              

              lines = list(list(type='line', x0 = x0, x1 = x1, y0=mean(ds1$sdmin), y1=mean(ds1$sdmin), 
                           line=list(dash='dot', width=3, color = 'lightskyblue',  name = 'SD range')),
                        
                        list(type='line', x0 = x0, x1 = x1, y0=mean(ds1$sdmax), y1=mean(ds1$sdmax),  
                             line=list(dash='dot', width=3, color = 'lightskyblue',  name = 'SD range')),
                        
                        list(type='line', x0 = x0, x1 = x1, y0=mean(ds1$qmax), y1=mean(ds1$qmax), 
                             line=list(dash='dot', width=3, color = 'lightpink',  name = 'IQR')),  
                        
                        list(type='line', x0 = x0, x1 = x1, y0=mean(ds1$qmin), y1=mean(ds1$qmin), 
                             line=list(dash='dot', width=3, color = 'lightpink',  name = 'IQR')),
                        
                        list(type='line', x0 = x0, x1 = x1, y0=mean(ds1$hmean), y1=mean(ds1$hmean), 
                             line=list(dash='dot', width=3, color = 'steelblue',  name = 'historical mean'))  
                  )                    
              
          }
        }  
        
        
      p <- p %>%      
        layout(yaxis = list(title = "Parameter Value"),  xaxis = list(title = ""),
               title = 'Actuation change over Time',
               legend = list(orientation = "h", xanchor = "center", x = 0.5),
               shapes = lines) %>%


      config(displaylogo = FALSE) %>%
      config(modeBarButtonsToRemove = c("select2d", "lasso2d", "hoverClosestCartesian", "hoverCompareCartesian"))
      p
    
  })    
  
  


  output$act_table <- DT::renderDataTable({
    
    if (length(rea_act$out_act) > 0) {

        cols = c( "inx", "Station", "Act_Name", "Stroke", "var" )
        tmp = unique(rea_act$out_act[, cols])
        tmp = tmp[order(tmp$inx), ]
        DT::datatable(tmp, rownames = FALSE, selection = list(mode = 'single', selected = 1),
                      options = list(lengthMenu = c(10, 50, 100, 500),  pageLength = 10,  dom = 'Brtip',  deferRender = TRUE,
                                     scroller = TRUE
                      ))
    }
    
  })
  
  

}





#options(shiny.launch.browser = .rs.invokeShinyWindowViewer)

shinyApp(ui, server)







#===================================================================================



#----------------------------- Quality tab -----------------------

# tabPanel("Quality0",
# 
#          fluidRow(width=12,
#                   # column(width=2,  pickerInput("Station_act_input", "Station:",  choices = c(''),  multiple = FALSE) ) ,
#                   # column(width=2,  pickerInput("Actuation_act_input", "Actuation:",  choices = c(''),  multiple = FALSE) ) ,
#                   # column(width=2,  pickerInput("Stroke_act_input", "Stroke:",  choices = c(''),  multiple = FALSE) ) ,
#                   #br(),
#                   column(width=2,
#                          pickerInput("BatchNo_qua_input", "BatchMoNumber:",  choices = c(''), options = list('actions-box' = TRUE), multiple = TRUE) ),
#                   br(),
#                   column(width=2,   actionButton("calc_qua", "Apply")),
#                   column(width=12,  plotOutput("plot_quapie", height = 300) ),
# 
#                   column(width=6,   plotlyOutput("plot_qua1", height = 300
#                                                #dblclick = "plot_qua1_dblclick",
#                                                # brush = brushOpts(
#                                                #   id = "plot_qua1_brush",
#                                                #   resetOnNew = TRUE  )
#                                                )   ),
#                   column(width=6,   plotOutput("plot_qua2", height = 300,
#                                                 dblclick = "plot_qua2_dblclick",
#                                                 brush = brushOpts(
#                                                   id = "plot_qua2_brush",
#                                                   resetOnNew = TRUE  )) )
# 
# 
#                   ),
#           br(),
#           DT::dataTableOutput("table_qua1", width=1500)
# 
# 
#          ),





# #----------------------------- Quality tab -----------------------
# 
# 
# ranges_qua1 <- reactiveValues(x = NULL, y = NULL)
# ranges_qua2 <- reactiveValues(x = NULL, y = NULL)
# 
# 
# observeEvent( input$calc_qua, {
#   
#   
#   if (check_df('df_parts', mes=1) < 0) {return()}
#   
#   
#   
#   tmp = df_parts
#   tmp = isolate({
#     ix = which(tmp$BatchMoNumber %in% input$BatchNo_qua_input) 
#     tmp = tmp[ix, ]    # filter by batch number
#   })         
#   tmp$date  = as.POSIXct(tmp$date)
#   
#   ds0b <- reactiveVal(tmp)
#   
#   
#   # aggregated format (hours)
#   tmp = df_parts_ag
#   
#   tmp = isolate({
#     ix = which(tmp$BatchMoNumber %in% input$BatchNo_qua_input) 
#     tmp = tmp[ix, ]    # filter by batch number
#   })      
#   
#   dsb <- reactiveVal(tmp)
#   
#   ds0 <- reactiveVal(ds0b())
#   ds <- reactiveVal(dsb())
#   
#   
#   tmp = aggregate(x = ds()[, c('good_parts', 'bad_parts')], by = list(ds()$date), FUN = "sum",  na.rm = TRUE)
#   colnames(tmp)[1:1] = c('date')    
#   ds_t = reactiveVal(tmp)
#   
#   tmp = aggregate(x = ds()[, c('good_parts', 'bad_parts')], by = list(ds()$hours), FUN = "sum",  na.rm = TRUE)
#   colnames(tmp)[1:1] = c('hours')    
#   ds_hr = reactiveVal(tmp)    
#   
#   
#   
#   
#   # observeEvent(ranges_qua1$x, {
#   #   print(111)
#   # 
#   # 
#   #   if (!is.null(ranges_qua1$x))  {
#   #     print(ranges_qua1$x[1])
#   #     print(ranges_qua1$x[2])
#   # 
#   #     #ix = which((dsb()$date >= as.Date(strptime(ranges_qua1$x[1], "%Y-%m-%d"))) & (dsb()$date <= as.Date(strptime(ranges_qua1$x[2], "%Y-%m-%d")) ) )
#   #     ix = which((dsb()$date >= ranges_qua1$x[1]) & (dsb()$date <= ranges_qua1$x[2] ) )
#   #     ds(dsb()[ix, ])
#   # 
#   #     print(dsb())
#   #     print(ds_t())
#   # 
#   #     #ix = which((ds0b()$date >= as.Date(strptime(ranges_qua1$x[1], "%Y-%m-%d"))) & (ds0b()$date <= as.Date(strptime(ranges_qua1$x[2], "%Y-%m-%d")) ) )
#   #     ix = which((ds0b()$date >= ranges_qua1$x[1]) & (ds0b()$date <= ranges_qua1$x[2] ) )
#   #     ds0( ds0b()[ix, ])
#   # 
#   # 
#   #   } else {
#   #       ds0 (ds0b())
#   #       ds (dsb())
#   #       print(11100)
#   #   }
#   # 
#   # 
#   # }, ignoreNULL = FALSE)
#   
#   
#   # as.Date(strptime(as.POSIXct(1577383398, origin = "1970-01-01"), "%Y-%m-%d"))
#   #as.Date(strptime("2019-12-26 13:03:17 EST", "%Y-%m-%d"))
#   
#   
#   
#   # observeEvent(ranges_qua2$x, {
#   #   print(222)
#   #   if (!is.null(ranges_qua2$x))  {
#   #     print(ranges_qua2$x[1])
#   #     print(ranges_qua2$x[2])
#   # 
#   #     ix = which( (ds0b()$hours > ranges_qua2$x[1]) & (ds0b()$hours <= ranges_qua2$x[2])  )
#   #     ds0 (ds0b()[ix, ])
#   # 
#   #     ix = which( (dsb()$hours > ranges_qua2$x[1]) & (dsb()$hours <= ranges_qua2$x[2])  )
#   #     ds (dsb()[ix, ])
#   # 
#   # 
#   #   } else {
#   #     ds0 (ds0b())
#   #     ds (dsb())
#   #   }
#   # }, ignoreNULL = FALSE)
#   
#   
#   
#   
#   observeEvent(ds(), {      
#     
#     if (nrow(ds()) > 0) {
#       
#       fa1 = function(a) {
#         r = aggregate(x = a[, c('good_parts', 'bad_parts')], by = list(a$date), FUN = "sum",  na.rm = TRUE)
#         colnames(r)[1:1] = c('date')
#         return (r)
#       }
#       ds_t(fa1(ds()))    
#       
#       
#       fa2 = function(a) {
#         r = aggregate(x = a[, c('good_parts', 'bad_parts')], by = list(a$hours), FUN = "sum",  na.rm = TRUE)
#         colnames(r)[1:1] = c('hours')
#         return (r)
#       }    
#       ds_hr(fa2(ds()))
#       
#       print(77777)
#       
#     } else {
#       infomessage('Warning', 'No data was found in selected period!')        
#     }
#     
#   })
#   
#   
#   output$plot_quapie <- renderPlot({
#     
#     tmp = colSums(ds()[, c('good_parts', 'bad_parts')])
#     tmp = (as.data.frame(tmp / sum(tmp)))
#     colnames(tmp) = 'share'
#     tmp$class = rownames(tmp)
#     
#     
#     # Create a basic bar
#     p = ggplot(tmp, aes(x="", y=share, fill=class)) + geom_bar(stat="identity", width=1, color = "white")
#     
#     # Convert to pie (polar coordinates) and add labels
#     p = p + coord_polar("y", start=0) + geom_text(aes(label = paste0(round(share*100), "%")), position = position_stack(vjust = 0.5), color = "white")
#     
#     # Add color scale (hex colors)
#     p = p + scale_fill_manual(values= c('coral4', 'cyan4') )  
#     
#     # Remove labels and add title
#     p = p + labs(x = NULL, y = NULL, fill = NULL, title = "Quality - Parts Share")
#     
#     # Tidy up the theme
#     p = p + theme_classic() + theme(axis.line = element_blank(),
#                                     axis.text = element_blank(),
#                                     axis.ticks = element_blank(),
#                                     plot.title = element_text(hjust = 0.5, color = "#666666", size = 14))
#     p
#     
#   })
#   
#   
#   output$plot_qua1 <- renderPlotly({
#     
#     tmp = ds_t()
#     #tmp$date  = as.POSIXct(tmp$date)
#     tmp$quality = tmp$good_parts / (tmp$good_parts + tmp$bad_parts) *100
#     
#     
#     p <- ggplot(data = tmp, aes(x = date))
#     p <- p + geom_line(aes(y = quality), color = 'darkcyan', size = 1)
#     p <- p + geom_point(aes(y = quality), color = 'darkcyan', size = 2)
#     
#     #p <- p + scale_x_date(date_labels = "%d/%b/%Y")
#     p <- p + theme(axis.text.x = element_text(size = 14),
#                    axis.text.y.left = element_text(size = 14),
#                    axis.title.x = element_text(size=16),
#                    axis.title.y.left = element_text(size=16, face="bold")
#     )
#     p <- p + coord_cartesian(xlim = ranges_qua1$x , ylim = ranges_qua1$y , expand = TRUE)
#     
#     p <- ggplotly(  p  )
#     p
#     
#   })      
#   
#   
#   
#   # output$plot_qua1 <- renderPlot({
#   #   
#   #   tmp = ds_t()
#   #   #tmp$date  = as.POSIXct(tmp$date)
#   #   tmp$quality = tmp$good_parts / (tmp$good_parts + tmp$bad_parts) *100
#   #   
#   # 
#   #   p <- ggplot(data = tmp, aes(x = date))
#   #   p <- p + geom_line(aes(y = quality), color = 'darkcyan', size = 1)
#   #   p <- p + geom_point(aes(y = quality), color = 'darkcyan', size = 2)
#   #   
#   #   #p <- p + scale_x_date(date_labels = "%d/%b/%Y")
#   #   p <- p + theme(axis.text.x = element_text(size = 14),
#   #                  axis.text.y.left = element_text(size = 14),
#   #                  axis.title.x = element_text(size=16),
#   #                  axis.title.y.left = element_text(size=16, face="bold")
#   #   )
#   #   p <- p + coord_cartesian(xlim = ranges_qua1$x , ylim = ranges_qua1$y , expand = TRUE)
#   #   p
#   # })  
#   
#   
#   
#   output$plot_qua2 <- renderPlot({
#     
#     tmp = ds_hr()
#     tmp$quality = tmp$good_parts / (tmp$good_parts + tmp$bad_parts) *100
#     
#     
#     p <- ggplot(data = tmp, aes(x = hours))
#     p <- p + geom_line(aes(y = quality), color = 'darkcyan', size = 1)
#     p <- p + geom_point(aes(y = quality), color = 'darkcyan', size = 2)
#     
#     #p <- p + scale_x_date(date_labels = "%d/%b/%Y")
#     p <- p + theme(axis.text.x = element_text(size = 14),
#                    axis.text.y.left = element_text(size = 14),
#                    axis.title.x = element_text(size=16),
#                    axis.title.y.left = element_text(size=16, face="bold")
#     )
#     p <- p + coord_cartesian(xlim = ranges_qua2$x , ylim = ranges_qua2$y , expand = TRUE)
#     p
#   })  
#   
#   
#   output$table_qua1 <- DT::renderDataTable({
#     
#     cols = c("StartTime",  "EndTime",  "PartType", "BatchMoNumber", "BatchLotNumber", "SerialNumber", "bad_parts", "good_parts", "date", "hours")
#     
#     DT::datatable(ds0()[cols], filter = 'top', rownames = FALSE, selection = "none", #extensions = c('Buttons', 'Scroller'),
#                   options = list(lengthMenu = c(10, 50, 100, 500),  pageLength = 10,
#                                  dom = 'Bfrtip',  deferRender = TRUE
#                                  # scroller = TRUE, buttons = c('copy', 'csv', 'excel')
#                   ))
#     
#   })
#   
#   
# })
# 
# 
# # observeEvent(input$plot_qua1_dblclick, {
# #   brush <- input$plot_qua1_brush
# #   print(ranges_qua1$x)
# #   print(brush$xmin)
# #   
# #   if (!is.null(brush)) {
# #     
# #     #ranges_qua1$x <-  c( as.POSIXct(brush$xmin, origin = "1970-01-01"),  as.POSIXct(brush$xmax, origin = "1970-01-01"))
# #     ranges_qua1$x <-  c( as.Date(brush$xmin, origin = "1970-01-01"),  as.Date(brush$xmax, origin = "1970-01-01")) 
# #     ranges_qua1$y <- c(brush$ymin, brush$ymax)
# #     
# #   } else {
# #     ranges_qua1$x <- NULL
# #     ranges_qua1$y <- NULL
# #   } 
# #   print(ranges_qua1$x)
# #   
# # 
# # })   
# 
# 
# 
# 
# 
# # observeEvent(input$plot_qua2_dblclick, {
# #   brush <- input$plot_qua2_brush
# #   
# #   if (!is.null(brush)) {
# #     
# #     ranges_qua2$x <-  c(brush$xmin, brush$xmax)
# #     ranges_qua2$y <- c(brush$ymin, brush$ymax)
# #     
# #   } else {
# #     ranges_qua2$x <- NULL
# #     ranges_qua2$y <- NULL
# #   } 
# # })    

#===================================================================================


























